USE [yp]
GO

/****** Object:  Table [dbo].[saleseat]    Script Date: 2017-1-4 22:49:50 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[saleseat](
	[moviename] [nvarchar](36) NULL,
	[seatrow] [int] NULL,
	[seatcol] [int] NULL
) ON [PRIMARY]

GO


